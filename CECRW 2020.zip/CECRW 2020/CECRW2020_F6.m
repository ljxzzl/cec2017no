classdef CECRW2020_F6 < PROBLEM
    % <single> <real> <constrained>
    % CEC'2017 constrained optimization benchmark problem
    
    %------------------------------- Reference --------------------------------
    % G. Wu, R. Mallipeddi, and P. N. Suganthan, Problem definitions and
    % evaluation criteria for the CEC 2017 competition on constrained real-
    % parameter optimization, National University of Defense Technology, China,
    % 2016.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
    %  properties
    %         O;  % Optimal decision vector
    %  end
 properties
     Func_num=6;
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
           
            global initial_flag
            initial_flag = 0;
            Par     = Cal_par(obj.Func_num);
            D       = Par.n;
            g       = Par.g;
            h       = Par.h;
            xmin    = Par.xmin;
            xmax    = Par.xmax;
            obj.M = 1;
            obj.D =D;
            obj.lower    = xmin;
            obj.upper    =xmax;
            obj.encoding = ones(1,obj.D);
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,PopDec)
            [f,g,h] = cec20_func(PopDec,obj.Func_num);
            PopObj = f;
        end
        %% Calculate constraint violations
        function PopCon = CalCon(obj,PopDec)
            [f,g,h] = cec20_func(PopDec,obj.Func_num);
           PopCon = transpose([g; h]);
            [rows, cols] = size(PopCon);
            fprintf('PopCon的形状是 %d 行 x %d 列\n', rows, cols);
        end
           function score = CalMetric(obj,metName,Population)
        %CalMetric - calculate the metric value of a population
        %
        %   value = obj.CalMetric(Met,P) returns the metric value of a
        %   population P, where Met is a string denoting the name of a
        %   metric function.
        %
        %   Example:
        %       value = Problem.CalMetric('HV',Population);
        
            score = feval(metName,Population,obj);
        end 
    end
end
  
